public class Nominee {
    private String name;

    public Nominee(String name) {
        this.name = name;
    }

    public String toString() {
        return name;
    }
}